import React , { useState, useEffect } from 'react';
import axios from 'axios';

import {
    Chart as ChartJS,
    ArcElement,
    Tooltip,
    Legend
} from 'chart.js';

import { Pie } from 'react-chartjs-2';

ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
);



function allInformation()
{
    return(
        <>
            sdfsfs
        </>
    )
}




export default allInformation;