import React , { useState, useEffect } from 'react';
import axios from 'axios';

import {
    Chart as ChartJS,
    ArcElement,
    Tooltip,
    Legend
} from 'chart.js';

import { Pie } from 'react-chartjs-2';

ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
);

function EndYear()
{
    const [dataendyear,setData]         = useState([]);

    const [datastartyear,setStartYear]  = useState([]);

    const [intensity,setIntensity]      = useState([]);

    const [likelihood,setlikelihood]    = useState([]);

    const [relevance,setRelevance]      = useState([]);

    const [country,setCountry]          = useState([]);

    const [topic,setTopic]              = useState([]);

    const [region,setRegion]            = useState([]);

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/region');

                console.log(response);

                setRegion(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    
    const filterregion = region.filter(item => item._id!==null);

    const filterRegion = {
        labels : filterregion.map(item => item._id.toString()),

        datasets: [
            {
                data: filterregion.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/topic');

                console.log(response);

                setTopic(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    const filtertopic = topic.filter(item => item._id!==null);
    
    const filterTopic = {
        labels : filtertopic.map(item => item._id.toString()),

        datasets: [
            {
                data: filtertopic.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/endYearCounts');

                console.log(response);

                setData(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    const filteredendyearData = dataendyear.filter(item => item._id!==null);

    const filterEndYearData = {
        labels : filteredendyearData.map(item => item._id.toString()),

        datasets: [
            {
                data: filteredendyearData.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/country');

                console.log(response);

                setCountry(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    const filtercountry = country.filter(item => item._id!==null);

    const filterCountry = {
        labels : filtercountry.map(item => item._id.toString()),

        datasets: [
            {
                data: filtercountry.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/startYearCounts');

                console.log(response);

                setStartYear(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    const filteredstartyearData = datastartyear.filter(item => item._id!==null);

    const filterStartyearData = {
        labels : filteredstartyearData.map(item => item._id.toString()),

        datasets: [
            {
                data: filteredstartyearData.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }


    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/endYearCounts');

                console.log(response);

                setIntensity(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    },[]);

    const filterintensity = intensity.filter(item => item._id!==null);

    const filterIntensity = {
        labels : filterintensity.map(item => item._id.toString()),

        datasets: [
            {
                data: filterintensity.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }

    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/likelihood');

                console.log(response);

                setlikelihood(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    });

    
    const filterlikelihood = likelihood.filter(item => item._id!==null);

    const filterLikelihood = {
        labels : filterlikelihood.map(item => item._id.toString()),

        datasets: [
            {
                data: filterlikelihood.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }


    useEffect(() => {
        const fetchData = async() => {
            try {
                const response = await axios.get('http://localhost:3001/api/relevance');

                console.log(response);

                setRelevance(response.data);
            } catch (error) {
                console.error('Error fetching data:',error.message);
            }
        }

        fetchData();
    });

    const filterrelevance = relevance.filter(item => item._id!==null);

    const filterRelevance = {
        labels : filterrelevance.map(item => item._id.toString()),

        datasets: [
            {
                data: filterrelevance.map(item => item.count),
                backgroundColor: [
                'red',
                'blue',
                'green',
                'yellow',
                'orange',
                'pink',
                'black',
                ],
            },
        ],
    }



    return(
        <>
            <div className='charts'>
                <h2>End year Pie Chart</h2>
                <Pie data = {filterEndYearData}  id='end_year'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Intensity Pie Chart</h2>
                <Pie data={filterIntensity} id='intensity'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Likelihood Pie Chart</h2>
                <Pie data={filterLikelihood} id='likelihood'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Relevance Pie Chart</h2>
                <Pie data={filterRelevance} id='relevance'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Start Year Pie Chart</h2>
                <Pie data={filterStartyearData} id='start_year'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Country Pie Chart</h2>
                <Pie data={filterCountry} id='country'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Topics Pie Chart</h2>
                <Pie data={filterTopic} id='topic'/>
            </div>

            <br />
            <br />
            <br />
            <br />

            <div className='charts'>
                <h2>Regions Pie Chart</h2>
                <Pie data={filterRegion} id='region'/>
            </div>

        </>
    );

}


export default EndYear;