import './App.css';
import EndYear from './endyears.js';
import Information from './allInformation.js';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <>

    <div className="App">
      <header className="App-header">
        <h1>Charts</h1>
      </header>
    </div>

    <br />
    <br />

    <a href="/individualCharts" id='individualCharts' className='btn btn-primary'>Click Me For Individual Charts</a>

    <br />
    <br />
    <br />

    {/* <a href="/allInformationTogether" id='allInformation' className='btn btn-primary'>All Information</a> */}


      <BrowserRouter>
        <Routes>
          <Route path='/'>
            <Route path='individualCharts' element={<EndYear />} />
            {/* <Route path='allInformationTogether' element={<Information />} /> */}
          </Route>
        </Routes>      
      </BrowserRouter>

      

    </>
    
  );
}

export default App;
