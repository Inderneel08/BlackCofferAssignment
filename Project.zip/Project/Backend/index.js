const express   = require('express');
var app = express();
const moongoose = require('mongoose');
const fs = require('fs/promises'); 
const cors = require('cors'); 

moongoose.connect("mongodb://127.0.0.1:27017/BlackCofferAssignment");

const DataSchema = new moongoose.Schema({
    end_year:{type:Number, default: null},
    intensity:{type:Number, default: null},
    sector:{type:String, default: null},
    topic:{type:String, default: null},
    insight:{type:String, default:null},
    url:{type:String, default:null},
    region:{type:String, default:null},
    start_year:{type:Number,default:null},
    impact:{type:Number, default:null},
    added:{type:String, default:null},
    published:{type:String,default:null},
    country:{type:String,default:null},
    relevance:{type:Number,default:null},
    pestle:{type:String,default:null},
    source:{type:String,default:null},
    title:{type:String, default:null},
    likelihood:{type:Number, default:null},
});

// const DataModel = moongoose.model('datas',DataSchema);

const DataModel = moongoose.model('datas',DataSchema);

// DataModel.updateMany({ region: '' }, { $set: { region: null } })
//     .then(result => {
//         console.log('Documents updated successfully:', result);
//     })
//     .catch(err => {
//         console.error('Error updating documents:', err);
//     });

// DataModel.updateMany({country: ''},{$set: {country: null}});

// const rawData = fs.readFile('jsondata.json','utf-8')
//                     .then(rawData => {

//                         const jsonData = JSON.parse(rawData);
                        
                        // if(jsonData.sector===undefined){
                        //     jsonData.sector=null;
                        // }

                        // if(jsonData.topic===undefined){
                        //     jsonData.topic=null;
                        // }

                        // if(jsonData.insight===undefined){
                        //     jsonData.insight=null;
                        // }

                        // if(jsonData.url===undefined){
                        //     jsonData.url=null;
                        // }

                        // if(jsonData.region===undefined){
                        //     jsonData.region=null;
                        // }
                        
                        // if(jsonData.country===undefined){
                        //     jsonData.country=null;
                        //     console.log(jsonData);
                        // }
                        
                    //     DataModel.insertMany(jsonData);
                    // });

const fetchedData = async ()=>{
    
    try {
        const dataTobeFetched = await DataModel.find();
        
        return(dataTobeFetched);   
    } catch (error) {
        console.log(error.message);        
    }
}

app.use(cors());

app.get('/',async(req, res) =>{

    const fetchList = await fetchedData();

    res.json(fetchList);
});

app.get('/api/endYearCounts',async(req,res) =>{

    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$end_year",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }

});

app.get('/api/startYearCounts',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$start_year",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


app.get('/api/country',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$country",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/api/region',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$region",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }     
});

app.get('/api/topic',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$topic",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


app.get('/api/intensity',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$intensity",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/api/likelihood',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$likelihood",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

app.get('/api/relevance',async(req,res) =>{
    try {
        const counts = await DataModel.aggregate([
            {$group: {_id:"$relevance",count:{$sum:1}}},
            {$sort: {_id: 1}},
        ]);

        res.json(counts);
    } catch (error) {
        console.log("Error fetching end_year counts:",error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


const PORT = 3001;

app.listen(PORT,()=>{
    console.log(`Server running at port ${PORT}`);
});



// const main = async ()=>{
//     await moongoose.connect("mongodb://127.0.0.1:27017/BlackCofferAssignment");

//     const DataSchema = new moongoose.Schema({
//         end_year:{type:Number, default: -1000},
//         intensity:{type:Number, default: 1200},
//         sector:{type:String, default: ""},
//         topic:{type:String, default: ""},
//         insight:{type:String, default:""},
//         url:{type:String, default:""},
//         region:{type:String, default:""},
//         start_year:{type:Number,default:-1000},
//         impact:{type:Number, default:-1000},
//         added:{type:String, default:String},
//         published:{type:String,default:""},
//         country:{type:String,default:""},
//         relevance:{type:Number,default:-1000},
//         pestle:{type:String,default:""},
//         source:{type:String,default:""},
//         title:{type:String, default:""},
//         likelihood:{type:Number, default:-1000},
//     });

//     const DataModel = moongoose.model('datas',DataSchema);

//     const fetchedData = await DataModel.find();

//     console.log(fetchedData);
// }

// main();